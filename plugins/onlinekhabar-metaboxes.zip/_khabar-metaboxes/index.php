<?php
/**
 * Plugin Name:       onlinekhabar metaboxes
 * Plugin URI:        https://example.com/plugins/the-basics/
 * Description:       Adding Metaboxes for onlinekhabar
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Rusahang Limbu
 * Author URI:        https://author.example.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       onlinekhabar-metaboxes
 * Domain Path:       /languages
 */

 if( !defined('WPINC')) {
    die;
}

include_once('includes/metaboxes.php');
include_once('includes/enqueue-assets.php');