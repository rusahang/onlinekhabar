<?php
/**
 * Plugin Name:       onlinekhabar portfolio
 * Plugin URI:        https://example.com/plugins/the-basics/
 * Description:       Adding Custom post type Portfolio for onlinekhabar
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Rusahang Limbu
 * Author URI:        https://author.example.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       onlinekhabar-portfolio
 * Domain Path:       /languages
 */

 if(!defined('WPINC')){
     die;
 }

 include_once('includes/portfolio-post-type.php');
 include_once('includes/project-type-text.php');
 include_once('includes/skills-text.php');

 function onlinekhabarportfolio_activate(){
     onlinekhabar_portfolio_setup_post_type();
     onlinekhabar__pluginnane_register_project_type_text();
     onlinekhabar__pluginnane_register_skills_text();
     flush_rewrite_rules();
 }
 register_activation_hook(__FILE__, 'onlinekhabarportfolio_activate');

 function onlinekhabarportfolio_deactivate(){
     unregister_post_type('onlinekhabar_portfolio');
     unregister_taxonomy('onlinekhabar_project_type');
     unregister_taxonomy('onlinekhabar_skills');
     flush_rewrite_rules();
 }
 register_deactivation_hook(__FILE__, 'onlinekhabarportfolio_deactivate');