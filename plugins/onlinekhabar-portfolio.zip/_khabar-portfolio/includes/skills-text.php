<?php

function onlinekhabar__pluginnane_register_skills_text(){
    $labels =[
        'name'  => esc_attr_x('Skills Type', 'taxonomy general name', 'onlinekhabar-portfolio'),
        'singular_name' => esc_html_x('Skill', 'taxonomy singular name', 'onlinekhabar-portfolio'),
        'search_items' => esc_html__('Search Skills', 'onlinekhabar-portfolio'),
        'all_items' => esc_html__('All Skills', 'onlinekhabar-portfolio'),
        'parent_item' => esc_html__( 'Parent Skill', 'onlinekhabar-portfolio'),
        'parent_item_colon' => esc_html__( 'Parent Skill', '_onlinekhabar-portfolio'),
        'edit_item' => esc_html__('Edit Skill', 'onlinekhabar-portfolio'),
        'update_item' => esc_html__('Update Skill', 'onlinekhabar-portfolio'),
        'add_new_item' => esc_html__('Add New Skills', 'onlinekhabar-portfolio'),
        'new_item_name' => esc_html__('New Skill Name', 'onlinekhabar-portfolio'),
        'menu_name' => esc_html__('Skills', 'onlinekhabar-portfolio'),
    ];
    $args = array(
        'labels' => $labels,
        'hierarchical' => false,
        'show_admin_column' => true,
        'show_in_rest' => true,
        'rewrite' => ['slug' => 'skills'],
    );
    register_taxonomy('onlinekhabar_skills', ['onlinekhabar_portfolio'], $args);
}

add_action('init', 'onlinekhabar__pluginnane_register_skills_text');