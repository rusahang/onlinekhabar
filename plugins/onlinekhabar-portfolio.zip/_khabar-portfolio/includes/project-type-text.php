<?php

function onlinekhabar__pluginnane_register_project_type_text(){
    $labels =[
        'name'  => esc_attr_x('Project Type', 'taxonomy general name', 'onlinekhabar-portfolio'),
        'singular_name' => esc_html_x('Project Type', 'taxonomy singular name', 'onlinekhabar-portfolio'),
        'search_items' => esc_html__('Search Project Types', 'onlinekhabar-portfolio'),
        'all_items' => esc_html__('All Project Types', 'onlinekhabar-portfolio'),
        'parent_item' => esc_html__( 'Parent Project Type', 'onlinekhabar-portfolio'),
        'parent_item_colon' => esc_html__( 'Parent Project Type', '_onlinekhabar-portfolio'),
        'edit_item' => esc_html__('Edit Project Type', 'onlinekhabar-portfolio'),
        'update_item' => esc_html__('Update Project Type', 'onlinekhabar-portfolio'),
        'add_new_item' => esc_html__('Add New Project Type', 'onlinekhabar-portfolio'),
        'new_item_name' => esc_html__('New Project Name', 'onlinekhabar-portfolio'),
        'menu_name' => esc_html__('Project Type', 'onlinekhabar-portfolio'),
    ];
    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
        'show_admin_column' => true,
        'show_in_rest' => true,
        'rewrite' => ['slug' => 'project'],
    );
    register_taxonomy('onlinekhabar_project_type', ['onlinekhabar_portfolio'], $args);
}

add_action('init', 'onlinekhabar__pluginnane_register_project_type_text');